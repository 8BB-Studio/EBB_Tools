﻿using CustomRadioButton.MVVMs;
using CustomRadioButton.ViewModels;
using System.Windows.Media;

namespace CustomRadioButton
{
    public class MainViewModel : ViewModelBase
    {
        private ItemSelectorViewModel _itemSelector1;
        public ItemSelectorViewModel ItemSelector1
        {
            get => _itemSelector1;
            set
            {
                _itemSelector1 = value;
                OnPropertyChanged();
            }
        }

        private ItemSelectorViewModel _itemSelector2;
        public ItemSelectorViewModel ItemSelector2
        {
            get => _itemSelector2;
            set
            {
                _itemSelector2 = value;
                OnPropertyChanged();
            }
        }

        public MainViewModel()
        {
            ItemSelector1 = new ItemSelectorViewModel();
            ItemSelector1.Items.Clear();
            ItemSelector1.Items.Add(new OptionItem("Chamber1", Brushes.Violet, Brushes.White, true));
            ItemSelector1.Items.Add(new OptionItem("Chamber2", Brushes.Violet, Brushes.White));
            ItemSelector1.Items.Add(new OptionItem("Chamber3", Brushes.Violet, Brushes.White));

            ItemSelector2 = new ItemSelectorViewModel();
            ItemSelector2.Items.Clear();
            ItemSelector2.Items.Add(new OptionItem("Left", Brushes.Black, Brushes.Beige, true));
            ItemSelector2.Items.Add(new OptionItem("Center", Brushes.Black, Brushes.Beige));
            ItemSelector2.Items.Add(new OptionItem("Right", Brushes.Black, Brushes.Beige));
        }
    }
}
