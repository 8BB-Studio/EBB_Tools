﻿using CustomRadioButton.MVVMs;
using System.Windows.Media;

namespace CustomRadioButton
{
    public class OptionItem : ViewModelBase
    {
        private string _label;
        public string Label
        {
            get => _label;
            set { _label = value; OnPropertyChanged(); }
        }

        private bool _isSelected;
        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                _isSelected = value;
                OnPropertyChanged();
            }
        }

        private double _fontSize;
        public double FontSize
        {
            get => _fontSize;
            set { _fontSize = value; OnPropertyChanged(); }
        }

        private Brush _background = Brushes.Violet;
        public Brush Background
        {
            get => _background;
            set { _background = value; OnPropertyChanged(); }
        }

        private Brush _foreground = Brushes.White;
        public Brush Foreground
        {
            get => _foreground;
            set { _foreground = value; OnPropertyChanged(); }
        }

        private double _top;
        public double Top
        {
            get => _top;
            set { _top = value; OnPropertyChanged(); }
        }

        private double _left;
        public double Left
        {
            get => _left;
            set { _left = value; OnPropertyChanged(); }
        }

        private double _width;
        public double Width
        {
            get => _width;
            set { _width = value; OnPropertyChanged(); }
        }

        private double _height;
        public double Height
        {
            get => _height;
            set { _height = value; OnPropertyChanged(); }
        }

        public OptionItem(string label, Brush background, Brush foreground, bool isSelected = false, double fontSize = 22)
        {
            Label = label;
            Background = background;
            Foreground = foreground;
            IsSelected = isSelected;
            FontSize = fontSize;
        }
    }
}
