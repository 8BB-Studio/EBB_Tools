﻿using CustomRadioButton.ViewModels;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace CustomRadioButton.Views
{
    public partial class ItemSelectorView : UserControl
    {
        #region Properties
        public static readonly DependencyProperty CornerRadiusProperty = DependencyProperty.Register(nameof(CornerRadius), typeof(CornerRadius), typeof(ItemSelectorView), new FrameworkPropertyMetadata(new CornerRadius(20), FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));
        public CornerRadius CornerRadius
        {
            get => (CornerRadius)GetValue(CornerRadiusProperty);
            set => SetValue(CornerRadiusProperty, value);
        }
        public static readonly new DependencyProperty ForegroundProperty = DependencyProperty.Register(nameof(Foreground), typeof(Brush), typeof(ItemSelectorView), new FrameworkPropertyMetadata(Brushes.Violet, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));
        public new Brush Foreground
        {
            get => (Brush)GetValue(ForegroundProperty);
            set => SetValue(ForegroundProperty, value);
        }
        public static readonly new DependencyProperty BackgroundProperty = DependencyProperty.Register(nameof(Background), typeof(Brush), typeof(ItemSelectorView), new FrameworkPropertyMetadata(Brushes.Violet, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));
        public new Brush Background
        {
            get => (Brush)GetValue(BackgroundProperty);
            set => SetValue(BackgroundProperty, value);
        }
        public static readonly new DependencyProperty BorderThicknessProperty = DependencyProperty.Register(nameof(BorderThickness), typeof(Thickness), typeof(ItemSelectorView), new FrameworkPropertyMetadata(new Thickness(0), FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));
        public new Thickness BorderThickness
        {
            get => (Thickness)GetValue(BorderThicknessProperty);
            set => SetValue(BorderThicknessProperty, value);
        }
        public static readonly new DependencyProperty BorderBrushProperty = DependencyProperty.Register(nameof(BorderBrush), typeof(Brush), typeof(ItemSelectorView), new FrameworkPropertyMetadata(Brushes.Transparent, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));
        public new Brush BorderBrush
        {
            get => (Brush)GetValue(BorderBrushProperty);
            set => SetValue(BorderBrushProperty, value);
        }
        #endregion

        public ItemSelectorView()
        {
            InitializeComponent();

            this.Loaded += OnLoaded;
            this.SizeChanged += ItemSelectorView_SizeChanged;
            this.DataContextChanged += ItemSelectorView_DataContextChanged;
        }

        private void OnLoaded(object sender, RoutedEventArgs rea)
        {
            foreach (var item in ItemsPresenter.Items)
            {
                if (ItemsPresenter.ItemContainerGenerator.ContainerFromItem(item) is ContentPresenter cp)
                {
                    if (VisualTreeHelper.GetChild(cp, 0) is SelectorView view)
                    {
                        view.MouseLeftButtonDown += (s, e) =>
                        {
                            if (this.DataContext is ItemSelectorViewModel vm && item is OptionItem oi)
                            {
                                vm.SelectItem(oi);
                            }
                        };
                    }
                }
            }            
        }

        private bool _layoutUpdated = false;
        private void ItemSelectorView_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            if (!_layoutUpdated && DataContext is ItemSelectorViewModel vm)
            {
                vm.UpdateLayout(this.ActualWidth, this.ActualHeight);
                _layoutUpdated = true;
            }
        }

        private void ItemSelectorView_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (e.NewValue is ItemSelectorViewModel vm)
            {
                vm.UpdateLayout(this.ActualWidth, this.ActualHeight);
                if (this.ActualWidth > 0 && this.ActualHeight > 0)
                {
                    vm.UpdateLayout(this.ActualWidth, this.ActualHeight);
                }
                this.SizeChanged += (s, args) =>
                {
                    vm.UpdateLayout(this.ActualWidth, this.ActualHeight);
                };
            }
        }

    }
}
