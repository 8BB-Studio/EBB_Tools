﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace CustomRadioButton.Views
{
    /// <summary>
    /// SelectorView.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class SelectorView : UserControl
    {
        #region Properties
        public static readonly DependencyProperty LabelProperty = DependencyProperty.Register("Label", typeof(string), typeof(SelectorView));
        public string Label
        {
            get => (string)GetValue(LabelProperty);
            set => SetValue(LabelProperty, value);
        }
        public static readonly DependencyProperty IsSelectedProperty = DependencyProperty.Register("IsSelected", typeof(bool), typeof(SelectorView));
        public bool IsSelected
        {
            get => (bool)GetValue(IsSelectedProperty);
            set => SetValue(IsSelectedProperty, value);
        }
        public static readonly DependencyProperty CornerRadiusProperty = DependencyProperty.Register(nameof(CornerRadius), typeof(CornerRadius), typeof(SelectorView), new FrameworkPropertyMetadata(new CornerRadius(20)));
        public CornerRadius CornerRadius
        {
            get => (CornerRadius)GetValue(CornerRadiusProperty);
            set => SetValue(CornerRadiusProperty, value);
        }
        #endregion

        public SelectorView()
        {
            InitializeComponent();
            this.DataContextChanged += (s, e) => this.UpdateBindings();
        }

        private void UpdateBindings()
        {
            if (DataContext is OptionItem item)
            {
                this.SetBinding(IsSelectedProperty, new Binding(nameof(item.IsSelected)) { Source = item });
                this.SetBinding(LabelProperty, new Binding(nameof(item.Label)) { Source = item });
            }
        }

    }
}
