﻿using CustomRadioButton.MVVMs;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Media;

namespace CustomRadioButton.ViewModels
{
    public class ItemSelectorViewModel : ViewModelBase
    {
        private ObservableCollection<OptionItem> _items = new ObservableCollection<OptionItem>();
        public ObservableCollection<OptionItem> Items
        {
            get => _items;
            set { _items = value; OnPropertyChanged(); }
        }

        private OptionItem _selectedItem;
        public OptionItem SelectedItem
        {
            get => _selectedItem;
            set { _selectedItem = value; OnPropertyChanged(); }
        }

        private double _verticalGap = 5;
        public double VerticalGap
        {
            get => _verticalGap;
            set { _verticalGap = value; OnPropertyChanged(); }
        }
        private double _horizontalGap = 5;
        public double HorizontalGap
        {
            get => _horizontalGap;
            set { _horizontalGap = value; OnPropertyChanged(); }
        }
        
        public void SelectItem(OptionItem selected)
        {
            foreach (var item in Items)
            {
                item.IsSelected = false;
            }

            selected.IsSelected = true;
            SelectedItem = selected;
            OnPropertyChanged(nameof(SelectedItem));
        }

        public void UpdateLayout(double totalWidth, double totalHeight)
        {
            if (Items.Count == 0 || totalWidth <= 0 || totalHeight <= 0)
            {
                return;
            }

            double selectorHeight = totalHeight - (VerticalGap * 2);
            double selectorWidth = totalWidth - ((Items.Count + 1) * HorizontalGap);
            selectorWidth /= Items.Count;
            for (int i = 0; i < Items.Count; i++)
            {
                Items[i].Width = selectorWidth;
                Items[i].Height = selectorHeight;
                Items[i].Left = HorizontalGap + i * (selectorWidth + HorizontalGap);
                Items[i].Top = VerticalGap;
            }
        }
    }
}
